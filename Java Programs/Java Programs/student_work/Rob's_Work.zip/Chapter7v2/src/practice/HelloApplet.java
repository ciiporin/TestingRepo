package practice;

public class HelloApplet extends java.applet.Applet {
	public void paint(java.awt.Graphics graphics){
		graphics.drawString("Hello World", 70, 40);
	}

}
