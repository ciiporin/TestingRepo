package PortfolioTask;

public class Dog {

	int legs;
	boolean tail;
	String fur;
	
public int getlegs() {
	return legs;
}

public void setlegs(int legs){
	this.legs = legs;
}

public boolean gettail() {
	return tail;
	

}
public void settail(boolean tail){
	this.tail = tail;
}

public String getfur() {
	return fur;
}
public void setfur(String fur){
	this.fur = fur;
}
}
