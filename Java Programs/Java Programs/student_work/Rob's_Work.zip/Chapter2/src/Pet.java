
public class Pet {

	
	/**
	 * @param args
	 */

		int age;
		Float weight;
		Float height;
		String color;
		
		public void sleep (){
			System.out.println("goodnight, see you in the morning");
		}
		public void eat() {
			System.out.println("am soooo hungry, feed me!");
		}
		public String say(String aWord){
			String petResponse = "ok! Ok!" + aWord;
					return petResponse;
		}


}










