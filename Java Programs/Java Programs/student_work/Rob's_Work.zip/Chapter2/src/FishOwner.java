
public class FishOwner {

		public static void main (String[] args) {
			
				String petResponse;
				
				Fish myFish = new Fish ();
				myFish.dive(2);
				myFish.dive(97);
				myFish.dive(3);
				
				myFish.sleep();
				
				
				
				
		}
}
